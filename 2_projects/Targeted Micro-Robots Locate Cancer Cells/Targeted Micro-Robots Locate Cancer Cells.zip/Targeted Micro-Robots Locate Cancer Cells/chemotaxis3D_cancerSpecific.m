function cancerTypeSpecificTargeting()
    % Parameters
    gridSize = 50;     % Reduced grid size for performance (50x50x50)
    domainSize = 1.0;   % 1 mm³ domain
    dx = domainSize/(gridSize-1);
    dt = 0.05;          % Time step (s)
    totalTime = 10;     % Reduced simulation time (s)
    steps = round(totalTime/dt);
   
    % Cancer type parameters
    cancerTypes = {'Breast', 'Prostate', 'Pancreatic'};
    params = struct();
   
    % Breast cancer parameters
    params.Breast = struct(...
        'tumorShape', 'spherical', ...
        'tumorCenter', [0.5, 0.5, 0.5], ...
        'tumorRadius', 0.15, ...
        'secretionRate', 0.8, ...
        'ecmDensity', 0.3, ...
        'vascularity', 0.7, ...
        'hypoxia', 0.2 ...
    );
   
    % Prostate cancer parameters
    params.Prostate = struct(...
        'tumorShape', 'ellipsoid', ...
        'tumorCenter', [0.5, 0.5, 0.5], ...
        'tumorRadii', [0.12, 0.18, 0.15], ...
        'secretionRate', 0.6, ...
        'ecmDensity', 0.5, ...
        'vascularity', 0.4, ...
        'hypoxia', 0.4 ...
    );
   
    % Pancreatic cancer parameters
    params.Pancreatic = struct(...
        'tumorShape', 'spherical', ...
        'tumorCenter', [0.5, 0.5, 0.5], ...
        'tumorRadius', 0.15, ...
        'secretionRate', 0.9, ...
        'ecmDensity', 0.8, ...
        'vascularity', 0.3, ...
        'hypoxia', 0.6 ...
    );
   
    % Micro-robot parameters
    robotParams = struct(...
        'Dc', 0.1, ...
        'Drho', 0.01, ...
        'chi', 0.3, ...
        'k', 0.02, ...
        'kb', 0.2, ...
        'ku', 0.01, ...
        'injectionSite', [0.1, 0.5, 0.5] ...
    );
   
    % Create figure
    fig = figure('Position', [100, 100, 1200, 800]);
   
    % Run simulation for each cancer type
    for typeIdx = 1:numel(cancerTypes)
        cancerType = cancerTypes{typeIdx};
        fprintf('Simulating: %s cancer\n', cancerType);
       
        % Initialize 3D grid
        [X, Y, Z] = meshgrid(linspace(0, domainSize, gridSize), ...
                             linspace(0, domainSize, gridSize), ...
                             linspace(0, domainSize, gridSize));
       
        % Create tumor mask
        tumorMask = createTumorMask(X, Y, Z, params.(cancerType));
       
        % Create ECM mask
        ecmMask = params.(cancerType).ecmDensity * ones(gridSize, gridSize, gridSize);
       
        % Create vascular mask (simplified)
        vascularMask = createVascularNetwork(params.(cancerType).vascularity, gridSize);
       
        % Initialize concentrations
        c = zeros(gridSize, gridSize, gridSize);
        rho = zeros(gridSize, gridSize, gridSize);
        b = zeros(gridSize, gridSize, gridSize);
       
        % Set initial robot injection
        [~, injX] = min(abs(X(1,:,1) - robotParams.injectionSite(1)));
        [~, injY] = min(abs(Y(:,1,1) - robotParams.injectionSite(2)));
        [~, injZ] = min(abs(Z(1,1,:) - robotParams.injectionSite(3)));
        rho(max(1,injX-1):min(gridSize,injX+1), ...
            max(1,injY-1):min(gridSize,injY+1), ...
            max(1,injZ-1):min(gridSize,injZ+1)) = 1;
       
        % Create source term
        S = params.(cancerType).secretionRate * tumorMask;
       
        % Time-stepping
        for t = 1:steps
            % Calculate effective diffusion coefficients
            Dc_eff = robotParams.Dc ./ (1 + 2*ecmMask);
            Drho_eff = robotParams.Drho ./ (1 + 3*ecmMask);
           
            % Calculate chemoattractant gradient - FIXED THIS LINE
            [cx, cy, cz] = gradient3d(c, dx);
           
            % Update chemoattractant
            c = c + dt * (Dc_eff .* del3(c, dx) - robotParams.k*c + S);
           
            % Update free robots (simplified)
            rho = rho + dt * (Drho_eff .* del3(rho, dx) + ...
                robotParams.chi * divergence3d(rho, cx, cy, cz, dx) - ...
                robotParams.kb * rho .* tumorMask + robotParams.ku * b);
           
            % Update bound robots
            b = b + dt * (robotParams.kb * rho .* tumorMask - robotParams.ku * b);
           
            % Enforce boundary conditions
            rho = enforceBC(rho);
            b = enforceBC(b);
            c = enforceBC(c);
           
            % Ensure non-negativity
            rho = max(rho, 0);
            b = max(b, 0);
            c = max(c, 0);
        end
       
        % Visualization
        subplot(2, 3, typeIdx);
        visualizeTumorEnvironment(X, Y, Z, tumorMask, rho, b, cancerType);
       
        % Performance metrics
        subplot(2, 3, typeIdx+3);
        plotPerformanceMetrics(rho, b, tumorMask, dx);
    end
   
    sgtitle('3D Micro-Robot Targeting in Different Cancer Types', 'FontSize', 16);
end

%% Helper Functions
function tumorMask = createTumorMask(X, Y, Z, params)
    tumorMask = zeros(size(X));
    switch params.tumorShape
        case 'spherical'
            dist = sqrt((X - params.tumorCenter(1)).^2 + ...
                   (Y - params.tumorCenter(2)).^2 + ...
                   (Z - params.tumorCenter(3)).^2);
            tumorMask(dist <= params.tumorRadius) = 1;
           
        case 'ellipsoid'
            dist = sqrt(((X - params.tumorCenter(1))/params.tumorRadii(1)).^2 + ...
                       ((Y - params.tumorCenter(2))/params.tumorRadii(2)).^2 + ...
                       ((Z - params.tumorCenter(3))/params.tumorRadii(3)).^2);
            tumorMask(dist <= 1) = 1;
    end
    % Smooth the mask using simple iterative smoothing
    tumorMask = simpleSmooth3D(tumorMask, 2); % 2 iterations
end

function smoothed = simpleSmooth3D(data, iterations)
    % Simple 3D smoothing using iterative averaging
    smoothed = data;
    [nx, ny, nz] = size(data);
    
    for iter = 1:iterations
        temp = smoothed;
        for i = 2:nx-1
            for j = 2:ny-1
                for k = 2:nz-1
                    % Average with 6-neighbors (3D cross)
                    smoothed(i,j,k) = (temp(i,j,k) + ...
                                      temp(i-1,j,k) + temp(i+1,j,k) + ...
                                      temp(i,j-1,k) + temp(i,j+1,k) + ...
                                      temp(i,j,k-1) + temp(i,j,k+1)) / 7;
                end
            end
        end
    end
end

function vascularMask = createVascularNetwork(vascularity, gridSize)
    % Create simple vascular network using random noise
    vascularMask = rand(gridSize, gridSize, gridSize);
    threshold = 1 - vascularity;
    vascularMask = vascularMask > threshold;
    vascularMask = double(vascularMask);
end

function u = enforceBC(u)
    % Neumann boundary conditions
    u(1,:,:) = u(2,:,:);
    u(end,:,:) = u(end-1,:,:);
    u(:,1,:) = u(:,2,:);
    u(:,end,:) = u(:,end-1,:);
    u(:,:,1) = u(:,:,2);
    u(:,:,end) = u(:,:,end-1);
end

function L = del3(u, dx)
    % 3D Laplacian with 7-point stencil
    L = zeros(size(u));
    L(2:end-1, 2:end-1, 2:end-1) = ...
        (u(1:end-2, 2:end-1, 2:end-1) + u(3:end, 2:end-1, 2:end-1) + ...
         u(2:end-1, 1:end-2, 2:end-1) + u(2:end-1, 3:end, 2:end-1) + ...
         u(2:end-1, 2:end-1, 1:end-2) + u(2:end-1, 2:end-1, 3:end) - ...
         6*u(2:end-1, 2:end-1, 2:end-1)) / dx^2;
end

function [gx, gy, gz] = gradient3d(u, dx)
    % 3D gradient
    gx = zeros(size(u));
    gy = zeros(size(u));
    gz = zeros(size(u));
    
    gx(2:end-1,:,:) = (u(3:end,:,:) - u(1:end-2,:,:)) / (2*dx);
    gy(:,2:end-1,:) = (u(:,3:end,:) - u(:,1:end-2,:)) / (2*dx);
    gz(:,:,2:end-1) = (u(:,:,3:end) - u(:,:,1:end-2)) / (2*dx);
    
    % Boundary conditions
    gx(1,:,:) = (u(2,:,:) - u(1,:,:)) / dx;
    gx(end,:,:) = (u(end,:,:) - u(end-1,:,:)) / dx;
    gy(:,1,:) = (u(:,2,:) - u(:,1,:)) / dx;
    gy(:,end,:) = (u(:,end,:) - u(:,end-1,:)) / dx;
    gz(:,:,1) = (u(:,:,2) - u(:,:,1)) / dx;
    gz(:,:,end) = (u(:,:,end) - u(:,:,end-1)) / dx;
end

function div = divergence3d(rho, cx, cy, cz, dx)
    % Compute ∇·(ρ∇c) for chemotaxis
    Fx = rho .* cx;
    Fy = rho .* cy;
    Fz = rho .* cz;
    
    [dFx, ~, ~] = gradient3d(Fx, dx);
    [~, dFy, ~] = gradient3d(Fy, dx);
    [~, ~, dFz] = gradient3d(Fz, dx);
    
    div = dFx + dFy + dFz;
end

function visualizeTumorEnvironment(X, Y, Z, tumorMask, rho, b, cancerType)
    % Create slice visualization
    xslice = 0.5; yslice = 0.5; zslice = 0.5;
    
    % Plot tumor slices
    slice(X, Y, Z, tumorMask, xslice, yslice, zslice);
    shading interp;
    colormap(jet);
    alpha(0.4);
    hold on;
    
    % Plot robot concentration slices
    total_robots = rho + b;
    h = slice(X, Y, Z, total_robots, xslice, yslice, zslice);
    set(h, 'EdgeColor', 'none', 'FaceAlpha', 0.7);
    
    % Plot injection site
    plot3(0.1, 0.5, 0.5, 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    
    title(sprintf('%s Cancer', cancerType));
    xlabel('X (mm)'); ylabel('Y (mm)'); zlabel('Z (mm)');
    colorbar;
    axis equal;
    view(3);
    xlim([0,1]); ylim([0,1]); zlim([0,1]);
end

function plotPerformanceMetrics(rho, b, tumorMask, dx)
    % Calculate metrics
    tumor_volume = sum(tumorMask(:)) * dx^3;
    total_robots = rho + b;
    
    tumor_robot_density = sum(total_robots(tumorMask > 0.5)) / tumor_volume;
    healthy_robot_density = sum(total_robots(tumorMask <= 0.5)) / (numel(tumorMask)*dx^3 - tumor_volume);
    binding_efficiency = sum(b(:)) / (sum(total_robots(:)) + eps);
    
    % Create bar plot
    metrics = [tumor_robot_density, healthy_robot_density, binding_efficiency];
    bar(metrics, 'FaceColor', [0.5, 0.7, 1.0]);
    
    set(gca, 'XTickLabel', {'Tumor Density', 'Healthy Density', 'Binding Eff.'});
    ylabel('Value');
    title('Performance Metrics');
    grid on;
    
    % Add values on bars
    for i = 1:3
        text(i, metrics(i)*0.9, sprintf('%.3f', metrics(i)), ...
            'HorizontalAlignment', 'center', 'Color', 'w', 'FontWeight', 'bold');
    end
end















