%% Parameters
L = 1;          % Domain size (mm)
N = 30;         % Grid points per dimension
dx = L/(N-1);   % Spatial resolution
dt = 0.001;     % Reduced time step for stability (s)
T = 2;          % Reduced simulation time for testing (s)
steps = round(T/dt);   % Number of steps

% Model parameters
Dc = 0.1;       % Chemoattractant diffusivity (mm²/s)
Drho = 0.01;    % Micro-robot diffusivity (mm²/s)
chi = 0.1;      % Reduced chemotactic sensitivity for stability
k = 0.02;       % Decay rate (1/s)
kb = 0.2;       % Binding rate (1/s)
ku = 0.01;      % Unbinding rate (1/s)
source_strength = 0.5; % Tumor source (nM/s)

%% Initialize 3D Grid
[x, y, z] = meshgrid(linspace(0,L,N), linspace(0,L,N), linspace(0,L,N));

% Tumor region (sphere at center)
tumor_center = [L/2, L/2, L/2];
tumor_radius = 0.15;
tumor_mask = sqrt((x-tumor_center(1)).^2 + ...
              (y-tumor_center(2)).^2 + ...
              (z-tumor_center(3)).^2) <= tumor_radius;

% Initial conditions
c = zeros(N,N,N);               % Chemoattractant
rho = zeros(N,N,N);             % Free micro-robots
rho(1:5,:,:) = 1;              % Initial injection at x=0 plane
b = zeros(N,N,N);               % Bound micro-robots
S = source_strength * double(tumor_mask); % Source term

% Add small noise to initial conditions for stability
rho = rho + 0.001 * randn(N,N,N);
c = c + 0.001 * randn(N,N,N);

fprintf('Starting simulation with %d steps...\n', steps);

%% Simulation
for t = 1:steps
    if mod(t, 100) == 0
        fprintf('Step %d/%d\n', t, steps);
    end
    
    % Apply boundary conditions first
    rho = enforce_BC(rho);
    b = enforce_BC(b);
    c = enforce_BC(c);
    
    % Calculate gradients for chemotaxis
    [cx, cy, cz] = gradient(c, dx, dx, dx);
   
    % Chemoattractant update (Diffusion + Production - Decay)
    c_laplacian = del3(c, dx);
    c = c + dt * (Dc * c_laplacian - k * c + S);
   
    % Micro-robot movement (Diffusion + Chemotaxis)
    rho_laplacian = del3(rho, dx);
    rho_divergence = divergence(rho, cx, cy, cz, dx);
    
    rho = rho + dt * (Drho * rho_laplacian - chi * rho_divergence);
   
    % Ensure non-negative concentrations
    rho = max(rho, 0);
    c = max(c, 0);
   
    % Binding kinetics (only in tumor region)
    binding = kb * rho .* tumor_mask;
    unbinding = ku * b;
    rho = rho - dt * binding + dt * unbinding;
    b = b + dt * binding - dt * unbinding;
    
    % Ensure non-negative concentrations
    b = max(b, 0);
end

fprintf('Simulation completed. Maximum concentration: %.4f\n', max(rho(:) + b(:)));

%% Visualization
total_robots = rho + b;

% Check if we have data to visualize
if max(total_robots(:)) > 0
    % Slice view
    figure(1);
    xslice = L/2; yslice = L/2; zslice = [0.2, 0.8];
    slice(x,y,z, total_robots, xslice, yslice, zslice);
    shading interp; colorbar; colormap(jet);
    title('Total Micro-robot Concentration');
    xlabel('X (mm)'); ylabel('Y (mm)'); zlabel('Z (mm)');

    % Isosurface view
    figure(2);
    isovalue = 0.1 * max(total_robots(:)); % Dynamic isovalue
    if max(total_robots(:)) > isovalue
        isosurface(x,y,z, total_robots, isovalue);
        axis equal; camlight; lighting gouraud;
        title(sprintf('Micro-robot Distribution (Isosurface at %.3f)', isovalue));
        xlabel('X (mm)'); ylabel('Y (mm)'); zlabel('Z (mm)');
    else
        fprintf('Concentrations too low for isosurface visualization.\n');
    end
    
    % Tumor region visualization
    figure(3);
    subplot(1,2,1);
    imagesc(squeeze(total_robots(:, :, round(N/2))));
    colorbar; title('Cross-section at z-center');
    
    subplot(1,2,2);
    imagesc(squeeze(tumor_mask(:, :, round(N/2))));
    colorbar; title('Tumor region');
    
else
    fprintf('No micro-robots detected. Simulation may have failed.\n');
end

%% Helper Functions
function L = del3(u, dx)
    % 3D Laplacian with zero-flux boundaries
    [Nx, Ny, Nz] = size(u);
    L = zeros(Nx, Ny, Nz);
    
    for i = 2:Nx-1
        for j = 2:Ny-1
            for k = 2:Nz-1
                L(i,j,k) = (u(i+1,j,k) + u(i-1,j,k) + ...
                           u(i,j+1,k) + u(i,j-1,k) + ...
                           u(i,j,k+1) + u(i,j,k-1) - 6*u(i,j,k)) / dx^2;
            end
        end
    end
end

function div = divergence(rho, cx, cy, cz, dx)
    % Compute ∇·(ρ∇c) for chemotaxis term
    [Nx, Ny, Nz] = size(rho);
    div = zeros(Nx, Ny, Nz);
    
    for i = 2:Nx-1
        for j = 2:Ny-1
            for k = 2:Nz-1
                % Calculate F = ρ∇c
                Fx = rho(i,j,k) * cx(i,j,k);
                Fy = rho(i,j,k) * cy(i,j,k);
                Fz = rho(i,j,k) * cz(i,j,k);
                
                % Calculate divergence using central differences
                dFx_dx = (rho(i+1,j,k)*cx(i+1,j,k) - rho(i-1,j,k)*cx(i-1,j,k)) / (2*dx);
                dFy_dy = (rho(i,j+1,k)*cy(i,j+1,k) - rho(i,j-1,k)*cy(i,j-1,k)) / (2*dx);
                dFz_dz = (rho(i,j,k+1)*cz(i,j,k+1) - rho(i,j,k-1)*cz(i,j,k-1)) / (2*dx);
                
                div(i,j,k) = dFx_dx + dFy_dy + dFz_dz;
            end
        end
    end
end

function u = enforce_BC(u)
    % Apply zero-flux boundary conditions
    u(1,:,:) = u(2,:,:);   u(end,:,:) = u(end-1,:,:);
    u(:,1,:) = u(:,2,:);   u(:,end,:) = u(:,end-1,:);
    u(:,:,1) = u(:,:,2);   u(:,:,end) = u(:,:,end-1);
end