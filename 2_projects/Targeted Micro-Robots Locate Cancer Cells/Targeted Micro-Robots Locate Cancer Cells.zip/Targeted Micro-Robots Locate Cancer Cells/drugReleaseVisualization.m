function drugReleaseVisualization()
    % Create figure
    figure;
   
    % Draw cancer cell (half-ellipsoid)
    [x, y, z] = ellipsoid(0,0,0, 8,8,5, 50);
    z(z<0) = 0; % Only top half
    surf(x+15, y+5, z+5, 'FaceColor', [1 0.6 0.6], 'EdgeColor', 'none');
    hold on;
   
    % Draw micro-robot (sphere with internal structure)
    [x, y, z] = sphere(50);
    surf(x*3+10, y*3+5, z*3+5, 'FaceColor', [0.7 0.7 1], 'EdgeColor', 'none', 'FaceAlpha', 0.9);
   
    % Draw drug payload (inside robot)
    [x, y, z] = sphere(30);
    surf(x*1.5+10, y*1.5+5, z*1.5+5, 'FaceColor', [0.8 0.4 1], 'EdgeColor', 'none');
   
    % Draw release mechanism (nanopores and drug particles)
    % Nanopores on the surface
    theta = linspace(0, 2*pi, 8);
    phi = linspace(0, pi, 8);
    [theta, phi] = meshgrid(theta, phi);
    r = 3.1;
    x_pore = r*sin(phi).*cos(theta) + 10;
    y_pore = r*sin(phi).*sin(theta) + 5;
    z_pore = r*cos(phi) + 5;
    % Only show pores facing the cancer cell
    mask = (x_pore > 10);
    scatter3(x_pore(mask), y_pore(mask), z_pore(mask), 20, 'k', 'filled');
   
    % Drug particles being released (as a stream)
    t = linspace(0, 1, 50);
    x_drug = 10 + 3*t;
    y_drug = 5 + 0.5*sin(5*t);
    z_drug = 5 + 0.5*cos(5*t);
    plot3(x_drug, y_drug, z_drug, 'm-', 'LineWidth', 2);
    scatter3(x_drug, y_drug, z_drug, 30, 'm', 'filled', 'MarkerFaceAlpha', 0.5);
   
    % Draw ligands binding to receptors
    % Ligands on robot surface
    ligand_pos = [10.5, 5.5, 5.5;
                  10.5, 4.5, 5.5;
                  10.5, 5, 6.5];
    % Receptors on cell
    receptor_pos = [14, 5.5, 5.5;
                    14, 4.5, 5.5;
                    14, 5, 6.5];
    for i = 1:size(ligand_pos,1)
        plot3([ligand_pos(i,1), receptor_pos(i,1)], ...
              [ligand_pos(i,2), receptor_pos(i,2)], ...
              [ligand_pos(i,3), receptor_pos(i,3)], ...
              'k', 'LineWidth', 1.5);
    end
   
    % Labeling
    text(10,5,5, 'Micro-Robot', 'Color', 'b', 'FontSize', 12, 'HorizontalAlignment', 'center');
    text(15,5,5, 'Cancer Cell', 'Color', 'r', 'FontSize', 12, 'HorizontalAlignment', 'center');
    text(12,5,5.5, 'Drug Particles', 'Color', 'm', 'FontSize', 10);
    text(11,5,3, 'Ligands', 'Color', 'k', 'FontSize', 10);
   
    % Formatting
    axis equal;
    xlim([0 20]); ylim([0 10]); zlim([0 10]);
    view(120, 30);
    title('Targeted Drug Release Mechanism');
    grid on;
    hold off;
end