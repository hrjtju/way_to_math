
function drugReleaseModel()
    % Parameters
    C0 = 100;       % Initial drug concentration (μM)
    tspan = [0 120]; % 120 minutes simulation
    n = [0.5, 1.2, 0.8, 1.5]; % Release exponents for different mechanisms
    
    % Define time vector for ODE solutions
    t_eval = linspace(tspan(1), tspan(2), 1000);
   
    % Trigger parameters
    params.magnetic.k = 0.15;
    params.thermal.k = 0.08; 
    params.thermal.Ea = 50; 
    params.thermal.R = 8.314; 
    params.thermal.T0 = 310;
    params.chemical.k = 0.12; 
    params.chemical.k_pH = 2.5; 
    params.chemical.pH_critical = 6.5;
    params.enzymatic.k = 0.2; 
    params.enzymatic.Km = 0.3;
   
    % Stimulus profiles (predefined as function handles)
    % Replace square wave with a custom pulse function
    magnetic_stim = @(t) 0.5*(1 + sign(sin(2*pi*t/30))); % Square wave alternative
    thermal_stim = @(t) 310 + 5*sin(2*pi*t/20);         % Oscillating temperature
    chemical_stim = @(t) 7.4 - 1.5*exp(-0.05*t);        % Exponential pH drop
    enzymatic_stim = @(t) min(0.1*t, 5);                % Linear enzyme increase with saturation
   
    % Solve ODEs
    options = odeset('RelTol',1e-6, 'MaxStep', 1);
    
    fprintf('Solving magnetic-triggered release...\n');
    [t_mag, C_mag] = ode45(@(t,y) dCdt(t, y, magnetic_stim, params, 'magnetic', n(1)), t_eval, C0, options);
    
    fprintf('Solving thermal-triggered release...\n');
    [t_therm, C_therm] = ode45(@(t,y) dCdt(t, y, thermal_stim, params, 'thermal', n(2)), t_eval, C0, options);
    
    fprintf('Solving chemical-triggered release...\n');
    [t_chem, C_chem] = ode45(@(t,y) dCdt(t, y, chemical_stim, params, 'chemical', n(3)), t_eval, C0, options);
    
    fprintf('Solving enzymatic-triggered release...\n');
    [t_enz, C_enz] = ode45(@(t,y) dCdt(t, y, enzymatic_stim, params, 'enzymatic', n(4)), t_eval, C0, options);
   
    % Plot results
    figure('Position', [100, 100, 1200, 500])
    
    % Subplot 1: Drug remaining
    subplot(1,2,1)
    plot(t_mag, C_mag, 'b-', 'LineWidth', 2)
    hold on
    plot(t_therm, C_therm, 'r-', 'LineWidth', 2)
    plot(t_chem, C_chem, 'g-', 'LineWidth', 2)
    plot(t_enz, C_enz, 'm-', 'LineWidth', 2)
    title('Drug Release Kinetics')
    xlabel('Time (min)')
    ylabel('Drug Remaining (%)')
    legend('Magnetic','Thermal','Chemical','Enzymatic', 'Location', 'northeast')
    grid on
    ylim([0 100])
    xlim(tspan)
   
    % Subplot 2: Cumulative drug release
    subplot(1,2,2)
    release_mag = 100 - C_mag;
    release_therm = 100 - C_therm;
    release_chem = 100 - C_chem;
    release_enz = 100 - C_enz;
    
    plot(t_mag, release_mag, 'b-', 'LineWidth', 2)
    hold on
    plot(t_therm, release_therm, 'r-', 'LineWidth', 2)
    plot(t_chem, release_chem, 'g-', 'LineWidth', 2)
    plot(t_enz, release_enz, 'm-', 'LineWidth', 2)
    title('Cumulative Drug Release')
    xlabel('Time (min)')
    ylabel('Drug Released (%)')
    legend('Magnetic','Thermal','Chemical','Enzymatic','Location','southeast')
    grid on
    ylim([0 100])
    xlim(tspan)

    % Calculate and display T50 values
    T50 = zeros(1,4);
    mechanisms = {'Magnetic', 'Thermal', 'Chemical', 'Enzymatic'};
    concentrations = {C_mag, C_therm, C_chem, C_enz};
    times = {t_mag, t_therm, t_chem, t_enz};
    
    fprintf('\nTime for 50%% release (min):\n');
    for i = 1:4
        idx = find(concentrations{i} <= 50, 1);
        if ~isempty(idx)
            T50(i) = times{i}(idx);
            fprintf('%s: %.2f min\n', mechanisms{i}, T50(i));
        else
            T50(i) = NaN;
            fprintf('%s: >120 min (not reached)\n', mechanisms{i});
        end
    end
    
    % Display in table format
    disp(' ');
    disp('Release Kinetics Summary:');
    disp(array2table(T50, 'VariableNames', mechanisms, 'RowNames', {'T50 (min)'}));
    
    % Plot stimulus profiles
    figure('Position', [100, 100, 800, 600])
    
    t_plot = linspace(0, 120, 500);
    
    subplot(2,2,1)
    plot(t_plot, arrayfun(magnetic_stim, t_plot), 'b-', 'LineWidth', 2)
    title('Magnetic Field Stimulus')
    xlabel('Time (min)')
    ylabel('Field Strength (a.u.)')
    grid on
    ylim([0 1])
    
    subplot(2,2,2)
    plot(t_plot, arrayfun(thermal_stim, t_plot), 'r-', 'LineWidth', 2)
    title('Temperature Stimulus')
    xlabel('Time (min)')
    ylabel('Temperature (K)')
    grid on
    ylim([305 315])
    
    subplot(2,2,3)
    plot(t_plot, arrayfun(chemical_stim, t_plot), 'g-', 'LineWidth', 2)
    title('pH Stimulus')
    xlabel('Time (min)')
    ylabel('pH')
    grid on
    ylim([5.5 7.5])
    
    subplot(2,2,4)
    plot(t_plot, arrayfun(enzymatic_stim, t_plot), 'm-', 'LineWidth', 2)
    title('Enzyme Concentration Stimulus')
    xlabel('Time (min)')
    ylabel('Enzyme Conc. (a.u.)')
    grid on
    ylim([0 6])
end

function dC = dCdt(t, C, stim_func, params, type, n)
    % Get stimulus value from function
    stim_val = stim_func(t);
    
    % Handle potential NaN values
    if isnan(stim_val) || isinf(stim_val)
        stim_val = 0;
    end
   
    % Calculate release rate constant based on stimulus type
    switch type
        case 'magnetic'
            k = params.magnetic.k * max(stim_val, 0);
        case 'thermal'
            % Arrhenius-type temperature dependence
            if stim_val > 0
                k = params.thermal.k * exp(-params.thermal.Ea/params.thermal.R * ...
                     (1/max(stim_val,300) - 1/params.thermal.T0));
            else
                k = 0;
            end
        case 'chemical'
            % Sigmoidal pH response (inverse relationship)
            k = params.chemical.k / (1 + exp(params.chemical.k_pH*(max(stim_val,4) - params.chemical.pH_critical)));
        case 'enzymatic'
            % Michaelis-Menten kinetics
            k = params.enzymatic.k * max(stim_val,0) / (params.enzymatic.Km + max(stim_val,0));
    end
   
    % Ensure k is non-negative
    k = max(k, 0);
    
    % Calculate derivative using modified release model
    % dC/dt = -k * C^n
    if C > 0
        dC = -k * (C^n);
    else
        dC = 0; % No more drug to release
    end
    
    % Add small term to prevent numerical instability
    if C < 0.1
        dC = 0;
    end
end