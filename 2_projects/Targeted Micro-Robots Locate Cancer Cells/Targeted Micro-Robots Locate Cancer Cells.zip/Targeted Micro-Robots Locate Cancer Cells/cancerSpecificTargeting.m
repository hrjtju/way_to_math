function cancerTypeSpecificTargeting()
    % Parameters
    gridSize = 100;     % 100x100x100 grid
    domainSize = 1.0;   % 1 mm³ domain (10x10x10 mm)
    dx = domainSize/(gridSize-1);
    dt = 0.05;          % Time step (s)
    totalTime = 30;     % Simulation time (s)
    steps = totalTime/dt;
   
    % Cancer type parameters
    cancerTypes = {'Breast', 'Prostate', 'Pancreatic'};
    params = struct();
   
    % Breast cancer parameters (luminal A subtype)
    params.Breast = struct(...
        'tumorShape', 'spherical', ...
        'tumorCenter', [0.5, 0.5, 0.5], ...
        'tumorRadius', 0.15, ...
        'secretionRate', 0.8, ...    % Chemoattractant secretion (nM/s)
        'ecmDensity', 0.3, ...       % Extracellular matrix density
        'vascularity', 0.7, ...       % Blood vessel density
        'hypoxia', 0.2 ...            % Hypoxic fraction
    );
   
    % Prostate cancer parameters
    params.Prostate = struct(...
        'tumorShape', 'ellipsoid', ...
        'tumorCenter', [0.5, 0.5, 0.5], ...
        'tumorRadii', [0.12, 0.18, 0.15], ... % [x,y,z] radii
        'secretionRate', 0.6, ...
        'ecmDensity', 0.5, ...
        'vascularity', 0.4, ...
        'hypoxia', 0.4 ...
    );
   
    % Pancreatic cancer parameters (desmoplastic)
    params.Pancreatic = struct(...
        'tumorShape', 'irregular', ...
        'tumorCenter', [0.5, 0.5, 0.5], ...
        'tumorRadius', 0.15, ...
        'secretionRate', 0.9, ...
        'ecmDensity', 0.8, ...
        'vascularity', 0.3, ...
        'hypoxia', 0.6 ...
    );
   
    % Micro-robot parameters (same for all simulations)
    robotParams = struct(...
        'Dc', 0.1, ...          % Chemoattractant diffusivity (mm²/s)
        'Drho', 0.01, ...       % Robot diffusivity (mm²/s)
        'chi', 0.3, ...         % Chemotactic sensitivity (mm²/(nM·s))
        'k', 0.02, ...          % Decay rate (1/s)
        'kb', 0.2, ...          % Binding rate (1/s)
        'ku', 0.01, ...         % Unbinding rate (1/s)
        'injectionSite', [0.1, 0.5, 0.5] ... % Injection location
    );
   
    % Create figure
    fig = figure('Position', [100, 100, 1200, 800]);
   
    % Run simulation for each cancer type
    for typeIdx = 1:numel(cancerTypes)
        cancerType = cancerTypes{typeIdx};
        fprintf('Simulating: %s cancer\n', cancerType);
       
        % Initialize 3D grid
        [X, Y, Z] = meshgrid(linspace(0, domainSize, gridSize), ...
                      linspace(0, domainSize, gridSize), ...
                      linspace(0, domainSize, gridSize));
       
        % Create tumor mask based on cancer type
        tumorMask = createTumorMask(X, Y, Z, params.(cancerType));
       
        % Create ECM mask (higher density = lower diffusion)
        ecmMask = params.(cancerType).ecmDensity * (1 + 0.5*randn(gridSize, gridSize, gridSize));
        ecmMask = max(min(ecmMask, 1), 0); % Clamp to [0,1]
       
        % Create vascular mask
        vascularMask = createVascularNetwork(params.(cancerType).vascularity, gridSize);
       
        % Initialize concentrations
        c = zeros(gridSize, gridSize, gridSize);    % Chemoattractant
        rho = zeros(gridSize, gridSize, gridSize);   % Free robots
        b = zeros(gridSize, gridSize, gridSize);     % Bound robots
       
        % Set initial robot injection
        [~, injX] = min(abs(X(1,:,1) - robotParams.injectionSite(1)));
        [~, injY] = min(abs(Y(:,1,1) - robotParams.injectionSite(2)));
        [~, injZ] = min(abs(Z(1,1,:) - robotParams.injectionSite(3)));
        rho(injX-2:injX+2, injY-2:injY+2, injZ-2:injZ+2) = 1;
       
        % Create source term based on secretion rate
        S = params.(cancerType).secretionRate * tumorMask;
       
        % Time-stepping
        for t = 1:steps
            % Calculate effective diffusion coefficients
            Dc_eff = robotParams.Dc ./ (1 + 2*ecmMask);
            Drho_eff = robotParams.Drho ./ (1 + 3*ecmMask);
           
            % Calculate chemoattractant gradient
            [cx, cy, cz] = gradient(c, dx, dx, dx);
           
            % Update chemoattractant (diffusion + secretion - decay)
            c = c + dt * (Dc_eff .* del3(c, dx) - robotParams.k*c + S);
           
            % Calculate robot flux (diffusion + chemotaxis)
            flux_x = -Drho_eff .* gradient(rho, dx, 1) + robotParams.chi * rho .* cx;
            flux_y = -Drho_eff .* gradient(rho, dx, 2) + robotParams.chi * rho .* cy;
            flux_z = -Drho_eff .* gradient(rho, dx, 3) + robotParams.chi * rho .* cz;
           
            % Update free robots
            rho = rho - dt * (divergence(flux_x, flux_y, flux_z, dx) + ...
                robotParams.kb * rho .* tumorMask - robotParams.ku * b);
           
            % Update bound robots
            b = b + dt * (robotParams.kb * rho .* tumorMask - robotParams.ku * b);
           
            % Apply vascular flow effect
            rho = advectWithFlow(rho, vascularMask, dx, dt);
           
            % Enforce boundary conditions
            rho = enforceBC(rho);
            b = enforceBC(b);
            c = enforceBC(c);
        end
       
        % Visualization
        subplot(2, 3, typeIdx);
        visualizeTumorEnvironment(X, Y, Z, tumorMask, rho, b, cancerType);
       
        % Performance metrics
        subplot(2, 3, typeIdx+3);
        plotPerformanceMetrics(rho, b, tumorMask, dx);
    end
   
    % Add overall title
    sgtitle('3D Micro-Robot Targeting in Different Cancer Types', 'FontSize', 16);
end

%% Helper Functions
function tumorMask = createTumorMask(X, Y, Z, params)
    tumorMask = zeros(size(X));
    switch params.tumorShape
        case 'spherical'
            dist = sqrt((X - params.tumorCenter(1)).^2 + ...
                   (Y - params.tumorCenter(2)).^2 + ...
                   (Z - params.tumorCenter(3)).^2);
            tumorMask(dist <= params.tumorRadius) = 1;
           
        case 'ellipsoid'
            dist = sqrt(((X - params.tumorCenter(1))/params.tumorRadii(1)).^2 + ...
                       ((Y - params.tumorCenter(2))/params.tumorRadii(2)).^2 + ...
                       ((Z - params.tumorCenter(3))/params.tumorRadii(3)).^2);
            tumorMask(dist <= 1) = 1;
           
        case 'irregular'
            % Base sphere
            dist = sqrt((X - params.tumorCenter(1)).^2 + ...
                   (Y - params.tumorCenter(2)).^2 + ...
                   (Z - params.tumorCenter(3)).^2);
            base = dist <= params.tumorRadius;
           
            % Add irregular protrusions
            [theta, phi] = meshgrid(linspace(0, 2*pi, 20), linspace(0, pi, 10));
            for i = 1:numel(theta)
                r_rand = params.tumorRadius * (1 + 0.3*randn());
                offset = 0.1 * randn(1,3);
                protrusion = createSphericalProtrusion(...
                    params.tumorCenter + offset, r_rand, size(X));
                tumorMask = tumorMask | base | protrusion;
            end
    end
    tumorMask = imgaussfilt3(tumorMask, 1); % Smooth edges
end

function protrusion = createSphericalProtrusion(center, radius, gridSize)
    [X, Y, Z] = meshgrid(linspace(0, 1, gridSize(2)), ...
                      linspace(0, 1, gridSize(1)), ...
                      linspace(0, 1, gridSize(3)));
    dist = sqrt((X - center(1)).^2 + (Y - center(2)).^2 + (Z - center(3)).^2);
    protrusion = dist <= radius;
end

function vascularMask = createVascularNetwork(vascularity, gridSize)
    % Create fractal vascular network using Perlin noise
    vascularMask = zeros(gridSize, gridSize, gridSize);
    [X, Y, Z] = meshgrid(1:gridSize, 1:gridSize, 1:gridSize);
   
    % Generate Perlin noise
    noise = perlinNoise3D(gridSize, 0.1);
   
    % Threshold to create vascular network
    threshold = 1.5 - 1.2*vascularity; % Higher vascularity → denser network
    vascularMask(noise > threshold) = 1;
   
    % Ensure connectivity
    vascularMask = imdilate(vascularMask, strel('sphere', 1));
end

function u = enforceBC(u)
    % Neumann boundary conditions (zero flux)
    u(1,:,:) = u(2,:,:);
    u(end,:,:) = u(end-1,:,:);
    u(:,1,:) = u(:,2,:);
    u(:,end,:) = u(:,end-1,:);
    u(:,:,1) = u(:,:,2);
    u(:,:,end) = u(:,:,end-1);
end

function L = del3(u, dx)
    % 3D Laplacian
    Lu = zeros(size(u));
    Lu(2:end-1, 2:end-1, 2:end-1) = ...
        (u(1:end-2, 2:end-1, 2:end-1) + u(3:end, 2:end-1, 2:end-1) + ...
         u(2:end-1, 1:end-2, 2:end-1) + u(2:end-1, 3:end, 2:end-1) + ...
         u(2:end-1, 2:end-1, 1:end-2) + u(2:end-1, 2:end-1, 3:end) - ...
         6*u(2:end-1, 2:end-1, 2:end-1)) / dx^2;
    L = Lu;
end

function div = divergence(Fx, Fy, Fz, dx)
    % Compute divergence of vector field
    dFx = gradient(Fx, dx, 1);
    dFy = gradient(Fy, dx, 2);
    dFz = gradient(Fz, dx, 3);
    div = dFx + dFy + dFz;
end

function u_advected = advectWithFlow(u, vascularMask, dx, dt)
    % Simple flow advection along vessels
    flowVelocity = 0.1; % mm/s
   
    % Create flow field (along vascular network)
    [vx, vy, vz] = gradient(vascularMask, dx);
    flowFieldX = flowVelocity * vx;
    flowFieldY = flowVelocity * vy;
    flowFieldZ = flowVelocity * vz;
   
    % Advection using upwind scheme
    u_advected = u - dt * ( ...
        max(flowFieldX,0).*gradient(u, dx, 1) + min(flowFieldX,0).*gradient(u, dx, 1, 'forward') + ...
        max(flowFieldY,0).*gradient(u, dx, 2) + min(flowFieldY,0).*gradient(u, dx, 2, 'forward') + ...
        max(flowFieldZ,0).*gradient(u, dx, 3) + min(flowFieldZ,0).*gradient(u, dx, 3, 'forward'));
end

function visualizeTumorEnvironment(X, Y, Z, tumorMask, rho, b, cancerType)
    % Create isosurfaces
    tumorIso = isosurface(X, Y, Z, tumorMask, 0.5);
    robotIso = isosurface(X, Y, Z, rho + b, 0.3);
   
    % Plot tumor
    p1 = patch(tumorIso, 'FaceColor', [1, 0.6, 0.6], 'EdgeColor', 'none', ...
        'FaceAlpha', 0.4, 'DisplayName', 'Tumor');
   
    % Plot robots
    hold on;
    p2 = patch(robotIso, 'FaceColor', [0.2, 0.5, 1.0], 'EdgeColor', 'none', ...
        'FaceAlpha', 0.6, 'DisplayName', 'Micro-Robots');
   
    % Plot injection site
    plot3(0.1, 0.5, 0.5, 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g', ...
        'DisplayName', 'Injection Site');
   
    % Formatting
    title(sprintf('%s Cancer Microenvironment', cancerType));
    xlabel('X (mm)'); ylabel('Y (mm)'); zlabel('Z (mm)');
    legend([p1, p2], {'Tumor', 'Micro-Robots'});
    axis equal; grid on; view(3);
    camlight; lighting gouraud;
    xlim([0,1]); ylim([0,1]); zlim([0,1]);
end

function plotPerformanceMetrics(rho, b, tumorMask, dx)
    % Calculate metrics
    tumorVolume = sum(tumorMask(:)) * dx^3;
    tumorRobotDensity = sum((rho(:) + b(:)) .* tumorMask(:)) / tumorVolume;
    healthyRobotDensity = sum(rho(:) + b(:)) / (numel(rho)*dx^3) - tumorRobotDensity;
    bindingEfficiency = sum(b(:)) / sum(rho(:) + b(:));
   
    % Create bar plot
    metrics = [tumorRobotDensity, healthyRobotDensity, bindingEfficiency];
    bar(metrics, 'FaceColor', [0.5, 0.7, 1.0]);
   
    % Labels and formatting
    set(gca, 'XTickLabel', {'Tumor Density', 'Healthy Density', 'Binding Eff.'});
    ylabel('Value');
    title('Performance Metrics');
    grid on;
   
    % Add text annotations
    text(1, metrics(1)*0.9, sprintf('%.2f', metrics(1)), ...
        'HorizontalAlignment', 'center', 'Color', 'w');
    text(2, metrics(2)*0.9, sprintf('%.2f', metrics(2)), ...
        'HorizontalAlignment', 'center', 'Color', 'w');
    text(3, metrics(3)*0.9, sprintf('%.2f', metrics(3)), ...
        'HorizontalAlignment', 'center', 'Color', 'w');
end

function noise = perlinNoise3D(gridSize, scale)
    % Simplified Perlin noise implementation
    [X, Y, Z] = meshgrid(1:gridSize, 1:gridSize, 1:gridSize);
    noise = sin(scale*X) .* cos(scale*Y) .* sin(scale*Z) + ...
            0.5*cos(scale*0.7*X) .* sin(scale*1.3*Y) .* cos(scale*0.9*Z);
    noise = (noise - min(noise(:))) / (max(noise(:)) - min(noise(:)));
end
