function immune_tumor_interaction()
    % Parameters
    L = 2;          % Domain size (mm)
    N = 100;        % Spatial points
    Tmax = 20;      % Simulation time (days)
    dt = 0.1;       % Time step (days)
   
    % Grid
    x = linspace(0, L, N);
    dx = x(2) - x(1);
   
    % Initial conditions
    T = 0.01*ones(N,1);       % T-cells
    C = exp(-100*(x-1).^2);   % Cancer cells (Gaussian tumor)
    A = zeros(N,1);           % Chemokines
    I_reg = 0.2*ones(N,1);    % Immunosuppressive factors
    D = zeros(N,1);           % Drug concentration
    M = zeros(N,1);           % Antigens
   
    % Micro-robot parameters
    robot_pos = 0.3;          % Injection site
    [~, idx_robot] = min(abs(x - robot_pos));
    release_rate = @(t) 5*exp(-0.5*t) .* (t <= 2); % Exponential release
   
    % Model parameters (days^-1)
    param.D_T = 1e-3;     param.chi_T = 0.1;   param.r_T = 1.2;
    param.K_T = 0.8;      param.d_T = 0.1;     param.k_bind = 0.3;
   
    param.r_C = 0.8;      param.K_C = 1.0;     param.gamma = 0.4;
    param.K_M = 0.2;      param.delta_C = 0.6;
   
    param.D_A = 2e-3;     param.alpha_A = 0.4; param.lambda_A = 0.7;
   
    param.D_I = 1e-3;     param.r_I = 0.25;    param.lambda_I = 0.2;
   
    param.D_D = 1e-3;     param.lambda_D = 1.0;
   
    param.D_M = 2e-3;     param.mu = 0.35;     param.lambda_M = 0.4;
   
    % Time-stepping
    for t = 0:dt:Tmax
        % Update drug source
        D(idx_robot) = D(idx_robot) + dt*release_rate(t);
       
        % Compute spatial derivatives
        dTdx = gradient(T, dx); d2Tdx2 = gradient(dTdx, dx);
        dCdx = gradient(C, dx);
        dAdx = gradient(A, dx); d2Adx2 = gradient(dAdx, dx);
        dIdx = gradient(I_reg, dx); d2Idx2 = gradient(dIdx, dx);
        dDdx = gradient(D, dx); d2Ddx2 = gradient(dDdx, dx);
        dMdx = gradient(M, dx); d2Mdx2 = gradient(dMdx, dx);
       
        % Reaction terms
        binding = param.k_bind * T .* C;
        killing = param.gamma * (T .* C) ./ (param.K_M + C);
       
        % PDE updates
        T = T + dt * ( ...
            param.D_T * d2Tdx2 ...                % Diffusion
            - param.chi_T * gradient(A.*dAdx, dx) ... % Chemotaxis
            + param.r_T * T .* (1 - T/param.K_T) ./ (1 + 0.5*I_reg) ... % Proliferation
            - param.d_T * T ...                   % Death
            - binding ...                         % Binding to cancer
            + 0.2*M./(0.1 + M) ...               % Antigen recruitment
            );
       
        C = C + dt * ( ...
            param.r_C * C .* (1 - C/param.K_C) ...% Growth
            - killing ...                         % T-cell killing
            - param.delta_C * D .* C ...          % Drug effect
            );
       
        A = A + dt * ( ...
            param.D_A * d2Adx2 ...                % Diffusion
            + param.alpha_A * D .* (0.8 - C) ...  % Drug-induced production
            - param.lambda_A * A ...              % Decay
            );
       
        I_reg = I_reg + dt * ( ...
            param.D_I * d2Idx2 ...                % Diffusion
            + param.r_I * C ...                   % Cancer production
            - param.lambda_I * T .* I_reg ...     % T-cell suppression
            );
       
        D = D + dt * ( ...
            param.D_D * d2Ddx2 ...                % Diffusion
            - param.lambda_D * D ...              % Decay
            );
       
        M = M + dt * ( ...
            param.D_M * d2Mdx2 ...                % Diffusion
            + param.mu * killing ...              % Release from killed cells
            - param.lambda_M * M ...              % Decay
            );
       
        % Enforce non-negativity
        T = max(T, 0); C = max(C, 0);
        A = max(A, 0); I_reg = max(I_reg, 0);
        D = max(D, 0); M = max(M, 0);
       
        % Visualization
        if mod(t,1) == 0
            plot_system(x, T, C, A, I_reg, D, M, t);
        end
    end
end

function plot_system(x, T, C, A, I, D, M, t)
    figure(1); clf;
   
    subplot(2,1,1);
    yyaxis left;
    plot(x, C, 'r-', 'LineWidth', 2); hold on;
    plot(x, T, 'b-', 'LineWidth', 2);
    ylabel('Cell Density');
    yyaxis right;
    plot(x, I, 'g-', 'LineWidth', 1.5);
    ylabel('Immunosuppression');
    title(sprintf('Tumor-Immune Dynamics (Day %.1f)', t));
    legend('Cancer Cells', 'T-cells', 'Immunosuppression');
    grid on;
   
    subplot(2,1,2);
    yyaxis left;
    plot(x, A, 'm-', 'LineWidth', 2); hold on;
    plot(x, M, 'c-', 'LineWidth', 2);
    ylabel('Concentration');
    yyaxis right;
    plot(x, D, 'k-', 'LineWidth', 2);
    ylabel('Drug Level');
    legend('Chemokines', 'Antigens', 'Drug');
    grid on;
   
    drawnow;
end