function chemotaxisSensitivityAnalysis()
    % Parameters
    L = 100; dx = 1; x = 0:dx:L; Nx = numel(x);
    Dc = 0.1; Drho = 0.01; k = 0.01; kb = 0.1; ku = 0.01;
    T = 200; dt = 0.1; Nt = round(T/dt);
    chi_values = [0.05, 0.1, 0.2];  % Chemotactic sensitivity values
   
    % Initialize storage for results
    rho_final = cell(numel(chi_values), 1);
    b_final = cell(numel(chi_values), 1);
    c_final = cell(numel(chi_values), 1);
    targeting_time = zeros(numel(chi_values), 1);
    efficiency = zeros(numel(chi_values), 1);
   
    % Common initial conditions
    rho0 = zeros(1, Nx); rho0(1:20) = 1;  % Initial injection at left boundary
    b0 = zeros(1, Nx);
    S = zeros(1, Nx); S(40:60) = 1;       % Tumor source term
   
    % Simulation loop for different chi values
    for idx = 1:numel(chi_values)
        chi = chi_values(idx);
        fprintf('Running simulation for chi = %.2f...\n', chi);
       
        % Initialize variables
        c = zeros(1, Nx);
        rho = rho0;
        b = b0;
        t_target = Inf;  % Time to reach tumor
       
        % Time-stepping
        for t = 1:Nt
            % Chemoattractant diffusion (Neumann BCs)
            c_new = c + dt * (Dc * del2_1d(c, dx) - k * c + S);
           
            % Calculate chemoattractant gradient
            grad_c = gradient_1d(c, dx);
           
            % Micro-robot movement (diffusion + chemotaxis)
            flux = -chi * rho .* grad_c;
            div_flux = gradient_1d(flux, dx);
            rho_new = rho + dt * (Drho * del2_1d(rho, dx) - div_flux);
           
            % Binding kinetics (only in tumor region)
            tumor_region = (x >= 40 & x <= 60);
            binding = kb * rho .* tumor_region;
            rho_new = rho_new - dt * binding;
            b_new = b + dt * (binding - ku * b);
           
            % Update variables
            c = c_new;
            rho = max(rho_new, 0);  % Ensure non-negative density
            b = max(b_new, 0);
           
            % Record targeting time (when >10% robots reach tumor)
            if t_target == Inf && sum(rho(40:60) + b(40:60)) > 0.1*sum(rho0)
                t_target = t * dt;
            end
        end
       
        % Store results
        rho_final{idx} = rho;
        b_final{idx} = b;
        c_final{idx} = c;
        targeting_time(idx) = t_target;
       
        % Calculate targeting efficiency
        total_in_tumor = sum(rho(40:60)) + sum(b(40:60));
        efficiency(idx) = sum(b(40:60)) / (total_in_tumor + eps);
        
        fprintf('  Targeting time: %.1f s, Efficiency: %.1f%%\n', t_target, efficiency(idx)*100);
    end

    %% Visualization
    % Create figure with 3 subplots
    figure('Position', [100, 100, 1200, 800])
   
    % Subplot 1: Concentration profiles
    subplot(2,2,1)
    colors = lines(3);
    hold on;
    for idx = 1:numel(chi_values)
        plot(x, rho_final{idx}, 'Color', colors(idx,:), 'LineWidth', 2, ...
             'DisplayName', sprintf('\\chi = %.2f (Free)', chi_values(idx)));
        plot(x, b_final{idx}, '--', 'Color', colors(idx,:), 'LineWidth', 2, ...
             'DisplayName', sprintf('\\chi = %.2f (Bound)', chi_values(idx)));
    end
    % Scale chemoattractant for visualization
    c_scaled = c_final{1}/max(c_final{1})*max([rho_final{1}, b_final{1}]);
    plot(x, c_scaled, 'k:', 'LineWidth', 1.5, ...
         'DisplayName', 'Chemoattractant');
    
    % Mark tumor region
    xline(40, 'r--', 'LineWidth', 1.5); 
    xline(60, 'r--', 'LineWidth', 1.5);
    text(50, 0.9*max(ylim), 'Tumor', 'Color', 'r', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    title('Micro-Robot Distribution')
    xlabel('Position (μm)'); ylabel('Density')
    legend('Location', 'northwest'); grid on
    xlim([0 L]);
   
    % Subplot 2: Performance metrics
    subplot(2,2,2)
    yyaxis left
    plot(chi_values, targeting_time, 'bo-', 'LineWidth', 2, 'MarkerSize', 10, 'MarkerFaceColor', 'b')
    ylabel('Targeting Time (s)')
    set(gca, 'YColor', 'b')
    
    yyaxis right
    plot(chi_values, efficiency*100, 'rs-', 'LineWidth', 2, 'MarkerSize', 10, 'MarkerFaceColor', 'r')
    ylabel('Binding Efficiency (%)')
    set(gca, 'YColor', 'r')
    
    title('Sensitivity Performance')
    xlabel('Chemotactic Sensitivity (\chi)')
    grid on
    legend({'Targeting Time', 'Binding Efficiency'}, 'Location', 'best')
   
    % Subplot 3: Temporal evolution (for medium chi)
    subplot(2,2,[3,4])
    chi_idx = find(chi_values == 0.1, 1);
    if isempty(chi_idx)
        chi_idx = 2; % Use middle value if 0.1 not found
    end
    
    [rho_hist, b_hist] = run_temporal_simulation(chi_values(chi_idx), rho0, b0, S, Dc, Drho, k, kb, ku, Nt, dt, dx, x);
   
    % Create space-time plot
    time_vector = (0:Nt-1)*dt;
    [T_grid, X_grid] = meshgrid(time_vector, x);
    
    total_density = rho_hist' + b_hist';
    pcolor(X_grid, T_grid, total_density)
    shading interp
    colormap(jet)
    colorbar
    hold on
    
    % Add contour lines
    [C, h] = contour(X_grid, T_grid, total_density, [0.01, 0.05, 0.1], 'w', 'LineWidth', 1);
    clabel(C, h, 'Color', 'w', 'FontWeight', 'bold');
    
    % Mark tumor region
    xline(40, 'w--', 'LineWidth', 2); 
    xline(60, 'w--', 'LineWidth', 2);
    text(50, max(time_vector)*0.05, 'Tumor Region', 'Color', 'w', ...
         'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'BackgroundColor', 'k');
    
    title(sprintf('Space-Time Evolution (\\chi = %.2f)', chi_values(chi_idx)))
    xlabel('Position (μm)'); ylabel('Time (s)')
    xlim([0 L]); ylim([0 T]);
    
    % Add performance metrics to title
    sgtitle(sprintf('Chemotactic Sensitivity Analysis: Higher \\chi Reduces Targeting Time (%.1fs → %.1fs)', ...
        targeting_time(1), targeting_time(end)), 'FontSize', 14)
end

%% Helper functions
function d2u = del2_1d(u, dx)
    % Second derivative with Neumann BCs
    d2u = zeros(size(u));
    d2u(2:end-1) = (u(1:end-2) - 2*u(2:end-1) + u(3:end)) / dx^2;
    d2u(1) = (u(2) - u(1)) / dx^2;       % Approximate Neumann
    d2u(end) = (u(end-1) - u(end)) / dx^2; % Approximate Neumann
end

function du = gradient_1d(u, dx)
    % First derivative with central differences
    du = zeros(size(u));
    du(2:end-1) = (u(3:end) - u(1:end-2)) / (2*dx);
    du(1) = (u(2) - u(1)) / dx;          % Forward difference
    du(end) = (u(end) - u(end-1)) / dx;   % Backward difference
end

function [rho_hist, b_hist] = run_temporal_simulation(chi, rho0, b0, S, Dc, Drho, k, kb, ku, Nt, dt, dx, x)
    % Initialize
    c = zeros(size(rho0));
    rho = rho0;
    b = b0;
    rho_hist = zeros(Nt, length(x));
    b_hist = zeros(Nt, length(x));
    
    tumor_region = (x >= 40 & x <= 60);
   
    % Time-stepping
    for t = 1:Nt
        % Chemoattractant
        c = c + dt * (Dc * del2_1d(c, dx) - k * c + S);
       
        % Gradient calculation
        grad_c = gradient_1d(c, dx);
       
        % Micro-robot movement
        flux = -chi * rho .* grad_c;
        div_flux = gradient_1d(flux, dx);
        rho_new = rho + dt * (Drho * del2_1d(rho, dx) - div_flux);
       
        % Binding kinetics
        binding = kb * rho .* tumor_region;
        rho_new = rho_new - dt * binding;
        b_new = b + dt * (binding - ku * b);
       
        % Update and store
        rho = max(rho_new, 0);
        b = max(b_new, 0);
        rho_hist(t,:) = rho;
        b_hist(t,:) = b;
    end
end