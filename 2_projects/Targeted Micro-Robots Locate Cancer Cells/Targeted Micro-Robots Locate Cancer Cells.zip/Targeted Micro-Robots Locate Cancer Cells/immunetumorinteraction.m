function tumorImmuneDrugModel()
    % Parameters
    Lx = 1; Ly = 1;   % Domain size (mm)
    Nx = 50; Ny = 50; % Reduced grid points for stability
    dx = Lx/(Nx-1); dy = Ly/(Ny-1);
    T_total = 5;      % Reduced simulation time (days)
    dt = 0.001;       % Smaller time step for stability
    Nt = round(T_total/dt);
   
    % Grid
    x = linspace(0, Lx, Nx);
    y = linspace(0, Ly, Ny);
    [X, Y] = meshgrid(x, y);
   
    % Model parameters (adjusted for stability)
    params.D_A = 1e-2;     % Chemokine diffusion (mm²/day)
    params.alpha_D = 0.1;  % Chemokine secretion by drug
    params.alpha_C = 0.05; % Chemokine secretion by cancer
    params.delta_A = 0.5;  % Chemokine decay
   
    params.D_T = 1e-3;     % T-cell diffusion (mm²/day)
    params.chi = 0.05;     % Reduced chemotactic sensitivity
    params.lambda_T = 0.8; % T-cell proliferation rate
    params.T_max = 10;     % T-cell carrying capacity
    params.gamma_TC = 0.2; % Killing rate by T-cells
    params.eta = 0.05;     % Antigen recruitment rate
   
    params.D_C = 1e-4;     % Cancer cell diffusion
    params.lambda_C = 0.6; % Cancer proliferation rate
    params.C_max = 20;     % Cancer carrying capacity
   
    params.D_D = 1e-2;     % Drug diffusion
    params.delta_D = 1.0;  % Drug decay
    params.D_M = 1e-2;     % Antigen diffusion
    params.mu = 0.1;       % Antigen release per killing event
    params.delta_M = 0.3;  % Antigen decay
   
    % Initial conditions
    T = zeros(Nx, Ny);     % T-cells
    % Two tumor nodules
    C = 3 * exp(-((X-0.3).^2 + (Y-0.3).^2)/0.02) + ...
        3 * exp(-((X-0.7).^2 + (Y-0.7).^2)/0.02);
    A = zeros(Nx, Ny);     % Chemokines
    D = zeros(Nx, Ny);     % Drug
    M = zeros(Nx, Ny);     % Antigens
   
    % Micro-robot drug source
    S_D = zeros(Nx, Ny);
    S_D = S_D + 8 * exp(-((X-0.3).^2 + (Y-0.3).^2)/0.002);
    S_D = S_D + 8 * exp(-((X-0.7).^2 + (Y-0.7).^2)/0.002);
   
    % Precompute Laplacian operator with zero-flux boundary conditions
    kernel = [0 1 0; 1 -4 1; 0 1 0] / (dx*dy);
    
    % For gradient calculations
    [~, gy] = gradient(zeros(Nx, Ny), dx, dy);
    grad_kernel_y = gy; % Template for gradient structure
   
    % Time stepping
    fprintf('Starting simulation...\n');
    for t = 1:Nt
        % Apply boundary conditions (zero-flux)
        A = applyBC(A);
        D = applyBC(D);
        T = applyBC(T);
        C = applyBC(C);
        M = applyBC(M);
       
        % 1. Update chemokine (A)
        lap_A = conv2(A, kernel, 'same');
        dA = params.D_A * lap_A + params.alpha_D*D + params.alpha_C*C - params.delta_A*A;
        A = A + dt * dA;
       
        % 2. Update drug (D)
        lap_D = conv2(D, kernel, 'same');
        dD = params.D_D * lap_D - params.delta_D*D + S_D;
        D = D + dt * dD;
       
        % 3. Update T-cells (T)
        lap_T = conv2(T, kernel, 'same');
        
        % Chemotaxis term using conservative discretization
        [Ax, Ay] = gradient(A, dx, dy);
        
        % Create flux components
        flux_x = params.chi * T .* Ax;
        flux_y = params.chi * T .* Ay;
        
        % Compute divergence of flux
        [div_flux_x, ~] = gradient(flux_x, dx, dy);
        [~, div_flux_y] = gradient(flux_y, dx, dy);
        chemotaxis_term = -(div_flux_x + div_flux_y);
       
        dT = params.D_T * lap_T + chemotaxis_term + ...
              params.lambda_T * T .* (1 - T/params.T_max) - ...
              params.gamma_TC * T .* C + ...
              params.eta * M;
        T = T + dt * dT;
        T = max(T, 0); % Non-negativity
       
        % 4. Update cancer cells (C)
        lap_C = conv2(C, kernel, 'same');
        dC = params.D_C * lap_C + ...
              params.lambda_C * C .* (1 - C/params.C_max) - ...
              params.gamma_TC * T .* C;
        C = C + dt * dC;
        C = max(C, 0);
       
        % 5. Update antigens (M)
        lap_M = conv2(M, kernel, 'same');
        dM = params.D_M * lap_M + params.mu * params.gamma_TC * T .* C - params.delta_M * M;
        M = M + dt * dM;
        M = max(M, 0);
       
        % Visualization every 500 steps
        if mod(t,500)==0
            fprintf('Time: %.2f days\n', t*dt);
            visualizeState(x, y, C, T, A, D, M, t*dt);
        end
    end
    
    fprintf('Simulation completed.\n');
end

function u = applyBC(u)
    % Apply zero-flux boundary conditions
    u(1,:) = u(2,:);      % Left boundary
    u(end,:) = u(end-1,:); % Right boundary
    u(:,1) = u(:,2);      % Bottom boundary
    u(:,end) = u(:,end-1); % Top boundary
end

function visualizeState(x, y, C, T, A, D, M, current_time)
    % Create visualization
    figure(1); clf;
    set(gcf, 'Position', [100, 100, 1200, 800]);
    
    subplot(2,3,1);
    imagesc(x, y, C);
    colorbar; title(sprintf('Cancer Cells (t=%.2f days)', current_time));
    axis equal; axis tight;
    
    subplot(2,3,2);
    imagesc(x, y, T);
    colorbar; title('T-cells');
    axis equal; axis tight;
    
    subplot(2,3,3);
    imagesc(x, y, A);
    colorbar; title('Chemokines');
    axis equal; axis tight;
    
    subplot(2,3,4);
    imagesc(x, y, D);
    colorbar; title('Drug Concentration');
    axis equal; axis tight;
    
    subplot(2,3,5);
    imagesc(x, y, M);
    colorbar; title('Antigens');
    axis equal; axis tight;
    
    % Tumor burden calculation
    subplot(2,3,6);
    tumor_volume = sum(C(:)) * (x(2)-x(1)) * (y(2)-y(1));
    tcell_count = sum(T(:)) * (x(2)-x(1)) * (y(2)-y(1));
    
    bar([tumor_volume, tcell_count]);
    set(gca, 'XTickLabel', {'Tumor Volume', 'T-cell Count'});
    title('Quantitative Measures');
    ylabel('Integrated Concentration');
    
    drawnow;
end