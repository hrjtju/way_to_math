function simulateRobotAndCells()
    % Parameters
    L = 20;         % Side length of the cubic box
    m = 50;         % Number of cells
    nSteps = 1000;  % Number of time steps
    dt = 0.1;       % Time step size

    % Chemotaxis parameters
    chi = 0.5;      % Chemotactic sensitivity
    D_robot = 0.01; % Diffusion coefficient for robot
    S = 1.0;        % Secretion rate per cell
    D_chemo = 0.1;  % Chemoattractant diffusivity
    k_decay = 0.01; % Decay rate of chemoattractant

    % Initialize positions and directions of cells
    positions = L * rand(m, 3);  % Random initial positions
    velocities = randn(m, 3);    % Random initial velocities
    velocities = velocities ./ vecnorm(velocities, 2, 2); % Normalize

    % Initial position of the micro-robot
    robotPosition = L * rand(1, 3);
    robotTrajectory = zeros(nSteps, 3);
    robotTrajectory(1, :) = robotPosition;

    % Simulation loop
    for t = 2:nSteps
        % Move cells
        positions = positions + velocities * dt;
        % Reflect cells off boundaries
        [positions, velocities] = reflectBoundary(positions, velocities, L);

        % Update micro-robot position
        grad = computeChemoGradient(robotPosition, positions, S, D_chemo, k_decay);
        deterministic_step = chi * grad * dt;
        random_step = sqrt(2*D_robot*dt) * randn(1,3);
        robotPosition = robotPosition + deterministic_step + random_step;

        % Reflect robot if it hits the boundary
        robotPosition = reflectRobot(robotPosition, L);
        robotTrajectory(t, :) = robotPosition;
    end

    % Plot the trajectory
    figure;
    plot3(robotTrajectory(:,1), robotTrajectory(:,2), robotTrajectory(:,3), 'm-', 'LineWidth', 1.5);
    hold on;
    plot3(positions(:,1), positions(:,2), positions(:,3), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    plot3(robotTrajectory(1,1), robotTrajectory(1,2), robotTrajectory(1,3), 'ks', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    plot3(robotTrajectory(end,1), robotTrajectory(end,2), robotTrajectory(end,3), 'ks', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    title('Targeted Micro-Robot Trajectory and Cancer Cells');
    legend('Robot Path', 'Cancer Cells', 'Start', 'End');
    grid on;
    axis([0 L 0 L 0 L]);
    hold off;
end

function [pos, vel] = reflectBoundary(pos, vel, L)
    % Handle boundary reflections for cells
    for i = 1:size(pos, 1)
        for j = 1:3
            if pos(i, j) <= 0
                vel(i, j) = abs(vel(i, j));
                pos(i, j) = 0;
            elseif pos(i, j) >= L
                vel(i, j) = -abs(vel(i, j));
                pos(i, j) = L;
            end
        end
    end
end

function newPos = reflectRobot(pos, L)
    % Reflect the robot if it goes beyond the boundary
    newPos = pos;
    for j = 1:3
        if newPos(j) < 0
            newPos(j) = -newPos(j);
        elseif newPos(j) > L
            newPos(j) = 2*L - newPos(j);
        end
    end
end

function grad = computeChemoGradient(robot, cellPos, S, D_chemo, k_decay)
    % Compute the gradient of the chemoattractant at the robot's position
    grad = zeros(1,3);
    for i = 1:size(cellPos,1)
        r_vec = robot - cellPos(i,:);
        r = norm(r_vec);
        if r < 1e-10
            continue; % Avoid division by zero
        end
        % Concentration from cell i: c_i = (S/(4*pi*D_chemo*r)) * exp(-r*sqrt(k_decay/D_chemo))
        % Precompute some terms
        lambda = sqrt(k_decay/D_chemo);
        c_i = (S/(4*pi*D_chemo*r)) * exp(-lambda*r);
        % Gradient of c_i with respect to r is:
        % dc_i/dr = c_i * [ -1/r - lambda ]
        % Then the gradient vector is: (dc_i/dr) * (r_vec / r)
        dc_dr = c_i * (-1/r - lambda);
        grad_i = dc_dr * (r_vec / r);
        grad = grad + grad_i;
    end
end
