% Parameters
L = 100; dx = 1; x = 0:dx:L; Nx = numel(x);
Dc = 0.1; Drho = 0.01; chi = 0.1; k = 0.01; kb = 0.1; ku = 0.01;
T = 200; dt = 0.1; Nt = T/dt;

% Initial conditions
c = zeros(1, Nx);
rho = zeros(1, Nx); rho(1:20) = 1;
b = zeros(1, Nx);
S = zeros(1, Nx); S(40:60) = 1;  % Tumor source

% Time-stepping
for t = 1:Nt
    % Chemoattractant diffusion (Neumann BCs)
    c_new = c + dt * (Dc * del2(c, dx) - k * c + S);
   
    % Micro-robot movement (central difference for gradient)
    grad_c = gradient(c, dx);
    chemotaxis_term = -chi * gradient(rho .* grad_c, dx);
    rho_new = rho + dt * (Drho * del2(rho, dx) + chemotaxis_term);
   
    % Binding (only in tumor region)
    binding = kb * rho .* (x >= 40 & x <= 60);
    rho_new = rho_new - dt * binding;
    b_new = b + dt * (binding - ku * b);
   
    % Update variables
    c = c_new; rho = rho_new; b = b_new;
end

% Plot results
plot(x, rho, 'b', x, b, 'r', x, c*max(rho)/max(c), 'g');
legend('Free Robots', 'Bound Robots', 'Chemoattractant');