function simulateRobotAndCells()
    % Parameters
    L = 20;         % Domain size (mm)
    m = 50;         % Number of cancer cells
    nSteps = 500;   % Time steps
    dt = 0.1;       % Time step (s)
   
    % Chemotaxis parameters
    chi = 0.8;      % Chemotactic sensitivity
    D_robot = 0.02; % Diffusion coefficient
    S = 0.5;        % Secretion rate per cell
    D_chemo = 0.1;  % Chemoattractant diffusivity
    k_decay = 0.01; % Decay rate
    lambda = sqrt(D_chemo/k_decay); % Gradient decay length
    beta = 0.3;     % Active targeting strength
   
    % Initialize cells (positions and velocities)
    positions = L * rand(m, 3);
    velocities = 0.2 * randn(m, 3);
    velocities = velocities ./ vecnorm(velocities, 2, 2);
   
    % Initialize micro-robot
    robotPosition = [0, 0, 0]; % Start at origin
    robotTrajectory = zeros(nSteps, 3);
    robotTrajectory(1, :) = robotPosition;
   
    % Obstacles (blood vessels)
    obstaclePos = [L/2, L/2, L/3;
                  L/4, 3*L/4, 2*L/3];
    obstacleRad = [1.5; 1.2];
   
    % Simulation loop
    for t = 2:nSteps
        % Update cell positions (with reflection)
        positions = positions + velocities * dt;
        [positions, velocities] = reflectBoundary(positions, velocities, L);
       
        % Calculate chemoattractant gradient at robot position
        grad = chemoGradient(robotPosition, positions, S, D_chemo, k_decay);
       
        % Active targeting component (nearest cell)
        [nearestDir, dist] = nearestCellDirection(robotPosition, positions);
        activeTarget = beta * nearestDir / (dist^2 + 1e-5); % Inverse square law
       
        % Avoid obstacles
        avoidForce = obstacleAvoidance(robotPosition, obstaclePos, obstacleRad);
       
        % Update robot position (chemotaxis + targeting + noise + avoidance)
        noise = sqrt(2*D_robot*dt) * randn(1,3);
        displacement = dt * (chi*grad + activeTarget) + noise + avoidForce;
        robotPosition = robotPosition + displacement;
       
        % Boundary reflection for robot
        robotPosition = max(min(robotPosition, L), 0);
       
        % Record trajectory
        robotTrajectory(t, :) = robotPosition;
        
        % Display progress
        if mod(t, 100) == 0
            fprintf('Step %d/%d, Current position: [%.2f, %.2f, %.2f]\n', ...
                    t, nSteps, robotPosition(1), robotPosition(2), robotPosition(3));
        end
    end

    % Visualization
    visualizeResults(positions, robotTrajectory, obstaclePos, obstacleRad, L);
end

%% Helper Functions
function [pos, vel] = reflectBoundary(pos, vel, L)
    % Handle boundary reflections
    for i = 1:size(pos, 1)
        for j = 1:3
            if pos(i,j) <= 0
                pos(i,j) = -pos(i,j); % Reflect position
                vel(i,j) = abs(vel(i,j)); % Reflect velocity
            elseif pos(i,j) >= L
                pos(i,j) = 2*L - pos(i,j); % Reflect position
                vel(i,j) = -abs(vel(i,j)); % Reflect velocity
            end
        end
    end
end

function grad = chemoGradient(robot, cellPos, S, D_chemo, k_decay)
    % Compute chemoattractant gradient at robot position
    grad = zeros(1,3);
    for i = 1:size(cellPos,1)
        r_vec = robot - cellPos(i,:);
        r = norm(r_vec);
        if r < 1e-10
            continue; % Avoid division by zero
        end
        % Correct gradient calculation for exponential decay
        % Concentration: c = (S/(4*pi*D_chemo*r)) * exp(-r*sqrt(k_decay/D_chemo))
        % Gradient: ∇c = -c * (1/r + sqrt(k_decay/D_chemo)) * (r_vec/r)
        decay_factor = sqrt(k_decay/D_chemo);
        c_i = (S/(4*pi*D_chemo*r)) * exp(-r*decay_factor);
        grad_i = -c_i * (1/r + decay_factor) * (r_vec/r);
        grad = grad + grad_i;
    end
end

function [dirVec, dist] = nearestCellDirection(robot, cellPos)
    % Find direction to nearest cancer cell
    dists = vecnorm(cellPos - robot, 2, 2);
    [dist, idx] = min(dists);
    if dist < 1e-10
        dirVec = randn(1,3); % Random direction if too close
        dirVec = dirVec / norm(dirVec);
    else
        dirVec = (cellPos(idx,:) - robot) / dist;
    end
end

function avoidForce = obstacleAvoidance(robot, obsPos, obsRad)
    % Compute obstacle avoidance force
    avoidForce = zeros(1,3);
    for i = 1:size(obsPos,1)
        r_vec = robot - obsPos(i,:);
        r = norm(r_vec);
        safe_distance = obsRad(i) + 0.8; % Safety margin
        if r < safe_distance
            % Repulsive force that increases as distance decreases
            strength = 2.0 * exp(-2*(r - obsRad(i))^2) / (r + 1e-5);
            avoidForce = avoidForce + strength * (r_vec/r);
        end
    end
    % Limit avoidance force to prevent excessive movement
    avoidNorm = norm(avoidForce);
    if avoidNorm > 1.0
        avoidForce = avoidForce / avoidNorm;
    end
end

function visualizeResults(cellPos, robotPath, obsPos, obsRad, L)
    % Create 3D visualization
    figure('Position', [100, 100, 1200, 800]);
   
    % Plot cancer cells
    scatter3(cellPos(:,1), cellPos(:,2), cellPos(:,3), ...
             50, 'ro', 'filled', 'MarkerFaceAlpha', 0.7);
    hold on;
   
    % Plot obstacles (blood vessels)
    [x,y,z] = sphere(20);
    for i = 1:size(obsPos,1)
        surf(obsRad(i)*x + obsPos(i,1), ...
             obsRad(i)*y + obsPos(i,2), ...
             obsRad(i)*z + obsPos(i,3), ...
             'FaceColor', [0.5 0.5 0.9], 'EdgeColor', 'none', 'FaceAlpha', 0.6);
    end
   
    % Plot robot path (color-coded by speed)
    pathVec = diff(robotPath);
    speed = vecnorm(pathVec, 2, 2);
    colorData = [speed; speed(end)]; % Extend to same length as path
    
    % Create colored line segments
    for i = 1:length(robotPath)-1
        plot3(robotPath(i:i+1,1), robotPath(i:i+1,2), robotPath(i:i+1,3), ...
              'Color', [colorData(i)/max(colorData), 0, 1-colorData(i)/max(colorData)], ...
              'LineWidth', 2);
    end
   
    % Mark start and end points
    plot3(robotPath(1,1), robotPath(1,2), robotPath(1,3), ...
          'gs', 'MarkerSize', 12, 'MarkerFaceColor', 'g', 'LineWidth', 2);
    plot3(robotPath(end,1), robotPath(end,2), robotPath(end,3), ...
          'bs', 'MarkerSize', 12, 'MarkerFaceColor', 'b', 'LineWidth', 2);
   
    % Formatting
    colormap(jet); 
    h = colorbar;
    ylabel(h, 'Speed (mm/s)');
    xlabel('X (mm)'); ylabel('Y (mm)'); zlabel('Z (mm)');
    title('Micro-Robot Navigation in Tumor Microenvironment');
    axis equal; grid on; view(3);
    xlim([0 L]); ylim([0 L]); zlim([0 L]);
    legend('Cancer Cells', 'Blood Vessels', 'Micro-Robot Path', 'Start', 'End');
    hold off;
   
    % Movement analysis
    figure('Position', [100, 100, 1000, 800]);
    
    subplot(2,2,1);
    speed = vecnorm(diff(robotPath), 2, 2);
    plot(speed, 'LineWidth', 1.5);
    title('Micro-Robot Speed Over Time');
    xlabel('Time Step'); ylabel('Speed (mm/s)');
    grid on;
   
    subplot(2,2,2);
    plot(robotPath(:,1), robotPath(:,2), 'b-', 'LineWidth', 1.5);
    hold on;
    scatter(cellPos(:,1), cellPos(:,2), 40, 'ro', 'filled');
    scatter(obsPos(:,1), obsPos(:,2), 100, 'square', 'filled', 'MarkerFaceColor', [0.5 0.5 0.9]);
    title('XY Projection');
    xlabel('X (mm)'); ylabel('Y (mm)');
    legend('Robot Path', 'Cancer Cells', 'Obstacles');
    axis equal; grid on;
    
    subplot(2,2,3);
    plot(robotPath(:,1), robotPath(:,3), 'b-', 'LineWidth', 1.5);
    hold on;
    scatter(cellPos(:,1), cellPos(:,3), 40, 'ro', 'filled');
    scatter(obsPos(:,1), obsPos(:,3), 100, 'square', 'filled', 'MarkerFaceColor', [0.5 0.5 0.9]);
    title('XZ Projection');
    xlabel('X (mm)'); ylabel('Z (mm)');
    axis equal; grid on;
    
    subplot(2,2,4);
    distances = vecnorm(robotPath - mean(cellPos), 2, 2);
    plot(distances, 'LineWidth', 1.5);
    title('Distance to Tumor Center');
    xlabel('Time Step'); ylabel('Distance (mm)');
    grid on;
end