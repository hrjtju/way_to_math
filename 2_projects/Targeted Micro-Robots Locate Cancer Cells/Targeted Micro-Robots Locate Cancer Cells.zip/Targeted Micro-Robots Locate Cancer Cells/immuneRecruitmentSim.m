function immuneRecruitmentSim()
    % Parameters
    gridSize = 200;     % 200x200 grid
    nSteps = 500;       % Simulation steps
    drugSource = [50, 50]; % Micro-robot position
   
    % Initialize agents
    cancerCells = randi([1, gridSize], 50, 2); % Cancer cell positions
    immuneCells = randi([1, gridSize], 20, 2);  % Initial immune cells
   
    % Drug diffusion parameters
    D = 0.2;            % Diffusion coefficient
    decay = 0.05;        % Drug decay rate
   
    % Initialize drug concentration grid
    drugConc = zeros(gridSize, gridSize);
    drugConc(drugSource(1), drugSource(2)) = 100; % Micro-robot drug source
   
    % Chemotaxis parameters
    chemoStrength = 0.3; % Immune cell attraction strength
    speed = 0.8;         % Immune cell speed
   
    % Setup visualization
    fig = figure('Position', [100, 100, 1000, 800]);
    ax = axes('Parent', fig);
    colormap(ax, 'hot');
   
    % Simulation loop
    for step = 1:nSteps
        % Update drug diffusion (2D diffusion with decay)
        drugConc = diffuseDrug(drugConc, D, decay, drugSource);
       
        % Move immune cells via chemotaxis
        [immuneCells, trails] = moveImmuneCells(immuneCells, drugConc, chemoStrength, speed, gridSize);
       
        % Visualize every 10 steps
        if mod(step,10) == 0
            cla(ax);
            imagesc(drugConc); hold on;
            axis equal; axis tight;
            % Plot cancer cells
            plot(cancerCells(:,2), cancerCells(:,1), 'mo', 'MarkerSize', 8, 'LineWidth', 1.5);
            % Plot immune cells
            plot(immuneCells(:,2), immuneCells(:,1), 'c>', 'MarkerSize', 10, 'MarkerFaceColor', 'c');
            % Plot movement trails
            for i = 1:size(trails,1)
                plot(trails{i}(:,2), trails{i}(:,1), 'c-', 'LineWidth', 0.5);
            end
            % Plot micro-robot
            plot(drugSource(2), drugSource(1), 'bs', 'MarkerSize', 15, 'MarkerFaceColor', 'b');
           
            title(sprintf('Immune Recruitment: Step %d/%d', step, nSteps));
            colorbar; caxis([0 100]);
            drawnow;
        end
    end
end

function drugNew = diffuseDrug(drug, D, decay, source)
    % 2D diffusion with Neumann boundary conditions
    kernel = [0 1 0; 1 -4 1; 0 1 0]; % Laplacian kernel
    lap = conv2(drug, kernel, 'same');
    drugNew = drug + D*lap - decay*drug;
    % Maintain source concentration
    drugNew(source(1), source(2)) = 100;
    drugNew = max(drugNew, 0);
end

function [cells, trails] = moveImmuneCells(cells, drug, chemoStr, speed, gridSize)
    trails = cell(size(cells,1),1);
    for i = 1:size(cells,1)
        x = round(cells(i,1)); y = round(cells(i,2));
        trail = [x,y];
       
        % Calculate gradient
        [gx, gy] = gradient(drug);
        if x>1 && x<gridSize && y>1 && y<gridSize
            dx = gx(x,y);
            dy = gy(x,y);
        else
            dx = 0; dy = 0;
        end
       
        % Move with chemotaxis + random exploration
        moveDir = chemoStr*[dx, dy] + (1-chemoStr)*randn(1,2);
        moveDir = moveDir/norm(moveDir + eps); % Normalize
       
        % Update position
        newPos = cells(i,:) + speed*moveDir;
        newPos = min(max(newPos,1), gridSize);
        cells(i,:) = newPos;
        trail = [trail; newPos];
        trails{i} = trail;
    end
end