
function navigationPathwayVisualization()
    % Parameters
    L = 20;         % Domain size (mm)
    m = 20;         % Number of cancer cells
    nSteps = 500;   % Time steps
    dt = 0.1;       % Time step (s)
   
    % Chemotaxis parameters
    chi = 0.8;      % Chemotactic sensitivity
    D_robot = 0.02; % Diffusion coefficient
    S = 0.5;        % Secretion rate per cell
    D_chemo = 0.1;  % Chemoattractant diffusivity
    k_decay = 0.01; % Decay rate
    lambda = sqrt(D_chemo/k_decay); % Gradient decay length
    beta = 0.3;     % Active targeting strength
   
    % Initialize cells (positions and velocities)
    positions = L * rand(m, 3);
    velocities = 0.2 * randn(m, 3);
    velocities = velocities ./ vecnorm(velocities, 2, 2);
   
    % Initialize micro-robot
    robotPosition = [0, 0, 0]; % Start at origin
    robotTrajectory = zeros(nSteps, 3);
    robotTrajectory(1, :) = robotPosition;
   
    % Obstacles (blood vessels)
    obstaclePos = [L/2, L/2, L/3;
                  L/4, 3*L/4, 2*L/3;
                  3*L/4, L/4, L/2];
    obstacleRad = [1.5; 1.2; 1.0];
   
    % Precompute chemoattractant field for visualization (on a grid)
    fprintf('Precomputing chemoattractant field...\n');
    [X,Y,Z] = meshgrid(linspace(0,L,20), linspace(0,L,20), linspace(0,L,20));
    C = zeros(size(X));
    for i = 1:size(X,1)
        for j = 1:size(Y,2)
            for k = 1:size(Z,3)
                pos = [X(i,j,k), Y(i,j,k), Z(i,j,k)];
                for c = 1:m
                    r = norm(pos - positions(c,:));
                    if r > 1e-10 % Avoid division by zero
                        C(i,j,k) = C(i,j,k) + (S/(4*pi*D_chemo*r)) * exp(-r/lambda);
                    else
                        C(i,j,k) = C(i,j,k) + 100; % Large value at cell positions
                    end
                end
            end
        end
    end
   
    % Simulation loop
    fprintf('Starting simulation...\n');
    for t = 2:nSteps
        % Update cell positions (with reflection)
        positions = positions + velocities * dt;
        [positions, velocities] = reflectBoundary(positions, velocities, L);
       
        % Calculate chemoattractant gradient at robot position
        grad = chemoGradient(robotPosition, positions, S, D_chemo, lambda);
       
        % Active targeting component (nearest cell)
        [nearestDir, dist] = nearestCellDirection(robotPosition, positions);
        activeTarget = beta * nearestDir / (dist^2 + 1e-5); % Inverse square law
       
        % Avoid obstacles
        avoidForce = obstacleAvoidance(robotPosition, obstaclePos, obstacleRad);
       
        % Update robot position (chemotaxis + targeting + noise + avoidance)
        noise = sqrt(2*D_robot*dt) * randn(1,3);
        robotPosition = robotPosition + dt * (chi*grad + activeTarget) + noise + avoidForce;
       
        % Boundary reflection for robot
        robotPosition = max(min(robotPosition, L), 0);
       
        % Record trajectory
        robotTrajectory(t, :) = robotPosition;
        
        % Display progress
        if mod(t, 100) == 0
            fprintf('Step %d/%d\n', t, nSteps);
        end
    end

    % Visualization of navigation pathway
    fprintf('Creating visualization...\n');
    figure('Position', [100, 100, 1200, 900]);
   
    % Plot chemoattractant isosurfaces
    isovalue = 0.1 * max(C(:)); % Dynamic isovalue
    if max(C(:)) > isovalue
        p1 = patch(isosurface(X, Y, Z, C, isovalue));
        isonormals(X, Y, Z, C, p1);
        set(p1, 'FaceColor', 'cyan', 'EdgeColor', 'none', 'FaceAlpha', 0.2);
        hold on;
    end
   
    % Plot obstacles
    [x,y,z] = sphere(20);
    for i = 1:size(obstaclePos,1)
        surf(obstacleRad(i)*x + obstaclePos(i,1), ...
             obstacleRad(i)*y + obstaclePos(i,2), ...
             obstacleRad(i)*z + obstaclePos(i,3), ...
             'FaceColor', [0.9 0.6 0.6], 'EdgeColor', 'none', 'FaceAlpha', 0.8);
    end
   
    % Plot cancer cells
    scatter3(positions(:,1), positions(:,2), positions(:,3), ...
             120, 'ro', 'filled', 'MarkerFaceAlpha', 0.8, 'MarkerEdgeColor', 'k');
   
    % Plot robot path with color coding based on speed
    pathVec = diff(robotTrajectory);
    speed = vecnorm(pathVec, 2, 2);
    
    % Create colored path segments
    for i = 1:length(robotTrajectory)-1
        colorRatio = speed(i)/max(speed);
        plot3(robotTrajectory(i:i+1,1), robotTrajectory(i:i+1,2), robotTrajectory(i:i+1,3), ...
              'Color', [colorRatio, 0, 1-colorRatio], 'LineWidth', 2.5);
    end
   
    % Mark start and end points
    plot3(robotTrajectory(1,1), robotTrajectory(1,2), robotTrajectory(1,3), ...
          'go', 'MarkerSize', 12, 'MarkerFaceColor', 'g', 'LineWidth', 2);
    plot3(robotTrajectory(end,1), robotTrajectory(end,2), robotTrajectory(end,3), ...
          'bo', 'MarkerSize', 12, 'MarkerFaceColor', 'b', 'LineWidth', 2);
   
    % Formatting
    xlabel('X (mm)'); ylabel('Y (mm)'); zlabel('Z (mm)');
    title('Micro-Robot Navigation Pathway in Tumor Microenvironment');
    axis equal; grid on; view(3);
    xlim([0 L]); ylim([0 L]); zlim([0 L]);
    
    % Create legend
    legendItems = {'Obstacles', 'Cancer Cells', 'Micro-Robot Path', 'Start', 'End'};
    if max(C(:)) > isovalue
        legendItems = ['Chemoattractant Field', legendItems];
    end
    legend(legendItems, 'Location', 'northeastoutside');
    
    camlight; lighting gouraud;
    colormap(jet);
    colorbar('Ticks', [0, 1], 'TickLabels', {'Slow', 'Fast'});
    ylabel(colorbar, 'Robot Speed');
    hold off;
    
    fprintf('Visualization complete.\n');
end

%% Helper Functions
function [pos, vel] = reflectBoundary(pos, vel, L)
    % Handle boundary reflections
    for i = 1:size(pos, 1)
        for j = 1:3
            if pos(i,j) <= 0
                pos(i,j) = -pos(i,j); % Reflect position
                vel(i,j) = abs(vel(i,j)); % Reflect velocity
            elseif pos(i,j) >= L
                pos(i,j) = 2*L - pos(i,j); % Reflect position
                vel(i,j) = -abs(vel(i,j)); % Reflect velocity
            end
        end
    end
end

function grad = chemoGradient(robot, cellPos, S, D_chemo, lambda)
    % Compute chemoattractant gradient at robot position
    grad = zeros(1,3);
    for i = 1:size(cellPos,1)
        r_vec = robot - cellPos(i,:);
        r = norm(r_vec);
        if r < 1e-10
            continue; % Avoid division by zero
        end
        % Concentration and gradient from single cell
        c_i = (S/(4*pi*D_chemo*r)) * exp(-r/lambda);
        grad_i = -c_i * (1/r + 1/lambda) * (r_vec/r);
        grad = grad + grad_i;
    end
end

function [dirVec, dist] = nearestCellDirection(robot, cellPos)
    % Find direction to nearest cancer cell
    dists = vecnorm(cellPos - robot, 2, 2);
    [dist, idx] = min(dists);
    if dist < 1e-10
        dirVec = randn(1,3); % Random direction if too close
        dirVec = dirVec / norm(dirVec);
    else
        dirVec = (cellPos(idx,:) - robot) / dist;
    end
end

function avoidForce = obstacleAvoidance(robot, obsPos, obsRad)
    % Compute obstacle avoidance force
    avoidForce = zeros(1,3);
    for i = 1:size(obsPos,1)
        r_vec = robot - obsPos(i,:);
        r = norm(r_vec);
        safe_distance = obsRad(i) + 0.8; % Safety margin
        if r < safe_distance
            % Repulsive force that increases as distance decreases
            strength = 2.0 * exp(-2*(r - obsRad(i))^2) / (r + 1e-5);
            avoidForce = avoidForce + strength * (r_vec/r);
        end
    end
    % Limit avoidance force to prevent excessive movement
    avoidNorm = norm(avoidForce);
    if avoidNorm > 1.0
        avoidForce = avoidForce / avoidNorm;
    end
end